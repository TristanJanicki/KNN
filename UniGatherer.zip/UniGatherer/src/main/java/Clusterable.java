public interface Clusterable {

    void setCluster(Object arg);

    Object getClusterLabel();

}
