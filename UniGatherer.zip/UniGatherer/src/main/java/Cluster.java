import java.awt.geom.Point2D;
import java.util.ArrayList;

public class Cluster implements Clusterable{

    ArrayList<UniGatherer.Uni> members;
    Point2D.Float centroid;
    String clusterLabel;

    public Cluster(){
        members = new ArrayList<UniGatherer.Uni>();
        centroid = new Point2D.Float();
        //centroid = new Point2D.Float(Float.MAX_VALUE, Float.MAX_VALUE);
    }

    Point2D computeCentroid(){
        float avgX = 0;
        float avgY = 0;

        for(UniGatherer.Uni p2d : members){
            avgX += p2d.latLng.getX();
            avgY += p2d.latLng.getY();
        }

        avgX /= members.size();
        avgY /= members.size();

        return centroid = new Point2D.Float(avgX, avgY);
    }

    @Override
    public void setCluster(Object arg) {
        clusterLabel = arg.toString();
    }

    @Override
    public Object getClusterLabel() {
        return this.clusterLabel;
    }
}
