import java.awt.geom.Point2D;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Clusterer {



    public static void main(String[] args){

        System.out.println("Running Clusterer");

        UniGatherer ug = new UniGatherer();


        Clusterer cluster = new Clusterer(5);
        Cluster[] C = cluster.setClusters(ug.searchByRegion("NorthAmerica"));

        System.out.println(cluster.classfiy(43.911868f, -79.4621135f));


        try{
            BufferedWriter bf = new BufferedWriter(new FileWriter(new File("C:\\Users\\trist\\clusters.txt")));
            BufferedWriter bf1 = new BufferedWriter(new FileWriter(new File("C:\\Users\\trist\\centroids.txt")));

            for(int i = 0; i < C.length; i ++){
                bf.write(C[i].members.toString().replace('[',' ').replace(']',';') + "\n");
                //System.out.println(C[i].members.toString().replace('[',' ').replace(']',';'));
            }

            for(int i = 0; i < C.length; i ++){
                bf1.write(C[i].centroid.x + "," + C[i].centroid.y + "\n");
                //System.out.println(C[i].centroid.x + "," + C[i].centroid.y);
            }

            bf.flush();
            bf1.flush();

            bf.close();
            bf1.close();
        }catch (IOException io){

        }

        //exec("python clusterPlotter.py");
    }
    
    Object classfiy (float lat, float lng){

        classfiy(lat, lng, this.k);

        return null;
    }

    Object classfiy (float lat, float lng, int k){

        UniGatherer.Uni[] nn = new UniGatherer.Uni[k];
        Arrays.fill(nn, UniGatherer.dummy);
        Point2D.Float point = new Point2D.Float(lng, lat);

        for(Cluster c : clusters){

            for(UniGatherer.Uni m : c.members){
                if(dist(point, m) < dist(point, nn[k-1])){
                    nn[k-1] = m;
                    //System.out.println(m.name);
                    for(int i = k -1; i > 0; i --){
                        if(dist(point, nn[i]) < dist(point, nn[i-1])){
                            UniGatherer.Uni temp = nn[i - 1];
                            //System.out.println("Swapping " + temp.name + " with " + nn[i].name);
                            nn[i - 1] = nn[i];
                            nn[i] = temp;
                        }
                    }
                }
            }
        }


        HashMap<String, Integer> hm = new HashMap<>();
        for(UniGatherer.Uni m : nn){
            hm.merge(m.getClusterLabel().toString(), 1, (a, b) -> a + b);
        }

        String name = "Nothing Searched Yet";
        int count = 0;

        for (Map.Entry<String, Integer> entry : hm.entrySet()) {
            String n = entry.getKey();
            Integer c = entry.getValue();
            if (c > count){
                name = n;
                count = c;
            }
        }

        System.out.println("Name = " + name + " count = " + count);
        System.out.println("The nearest " + nn.length + " neighbours are ");
        getClusterByLabel(name).members.forEach(m -> System.out.print(m.name + ","));
        return name;
    }

    Cluster getClusterByLabel(Object label){
        for(Cluster c : clusters){
            if (c.clusterLabel.equals(label)) return c;
        }
        return null;
    }

    // <editor-fold desc="Distance Functions">
    double dist(Point2D.Float p1, UniGatherer.Uni u1){
        return p1.distanceSq(u1.latLng);
    }

    double dist(UniGatherer.Uni u1, Point2D.Float p1){
        return Math.sqrt(u1.latLng.distanceSq(p1));
    }

    double dist(UniGatherer.Uni u1, UniGatherer.Uni u2){
        return u1.latLng.distanceSq(u2.latLng);
    }

    double dist(Point2D.Float p1, Point2D.Float p2){
        return p1.distanceSq(p2);
    }
    // </editor-fold>

    private static void exec(String e){
        Runtime r = Runtime.getRuntime();
        try {
            Process p = r.exec(e);

        } catch (IOException e1) {
            e1.printStackTrace();
        }


    }

    Cluster[] clusters;
    int k;

    public Clusterer(int k){
        this.k = k;
        clusters = new Cluster[k];

        for(int i = 0; i < k; i ++){
            clusters[i] = new Cluster();
            clusters[i].clusterLabel = String.valueOf(i);
        }

    }

    Cluster[] setClusters(List<UniGatherer.Uni> points){
        System.out.println("Setting clusters");
        // <editor-fold desc="pick random centroids">
        Random r = new Random();
        HashSet<Integer> usedNumbers = new HashSet<Integer>();
        for(int i = 0; i < clusters.length; i ++){


            int ri = r.nextInt(points.size());
            while(usedNumbers.contains(ri)) ri = r.nextInt(points.size());
            //System.out.println("ri = " + ri);
            usedNumbers.add(ri);
            clusters[i].centroid = points.get(ri).latLng;
            //System.out.println("Centroid of cluster " + i + " = " + clusters[i].centroid);
        }
        //</editor-fold>

        while(true){
            boolean centroidsSame = true;

            for(UniGatherer.Uni p : points){
                Cluster closest = null;

                for(Cluster c : clusters){
                    if(closest == null) closest = c;

                    if(dist(p, c.centroid) < dist(p, closest.centroid)){
                        closest = c;
                        //System.out.println("Set closest to " + closest.centroid);
                    }
                }
                closest.members.add(p);
                if(p instanceof Clusterable) p.setCluster(closest.clusterLabel);
                //System.out.println("Closest to " + p.name + " is " + closest.members.get(0).name);
            }


            // Recalculates
            for (Cluster cluster : clusters) {
                Point2D oc = cluster.centroid; // Old Centroid for this clusters
                Point2D nc = cluster.computeCentroid(); // New Centroid for this cluster
                //System.out.println("New Centroid = " + nc);
                if(!oc.equals(nc)) centroidsSame = false;
            }

            if (centroidsSame){
                break;
            }
            else{
                for (Cluster c : clusters) {
                    c.members.clear();
                }
            }
        }

        return this.clusters;
    }

    void setInitialsCentroids (Point2D.Float...centroids){
        if(centroids.length != clusters.length){
            System.out.println("You must enter k centroids");
            return;
        }

        for(int i = 0; i < centroids.length; i ++){
            clusters[i].centroid = centroids[i];
        }
    }

}
