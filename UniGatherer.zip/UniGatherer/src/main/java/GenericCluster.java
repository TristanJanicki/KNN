import java.awt.geom.Point2D;
import java.util.Arrays;

public class GenericCluster {

    RootishArrayStack<Feature> members = new RootishArrayStack<>(Feature.class);
    String clusterLabel = "None";
    double[] centroid;

    public GenericCluster(int featureCount){
        centroid = new double[members.size()];
    }

    class Feature {

        RootishArrayStack<Object> featureVector = new RootishArrayStack<>(Object.class);

        public Feature(Object... featureValues){
            featureVector.addAll(Arrays.asList(featureValues));
        }

        /**
         * This function computes this distance between two n-dimensional feature vectors. The distance between two qualitative features (e.g. String labels) will be computed using the <i>Hamming Distance</i>.
         * @param f Another feature to compute the similarity of.
         * @param type Distance type, either Euclidean, Manhattan, or Minkowski
         * @param q Only needed if type = Minkowski.
         * @return the distance between two feature vectors as defined by the distance equation specified in the <code>type</code> parameter.
         */
        double dist(Feature f, String type, double q){
            if(f.featureVector.size() != this.featureVector.size()) throw new RuntimeException("Computing Distance of 2 Feature Vectors With Different Sizes");
            double sum = 0;

            switch (type){
                case "euclidean":

                    for(int i = 0; i < featureVector.size(); i ++){
                        Object o = f.featureVector.get(i);
                        Object t = this.featureVector.get(i);

                        if(o instanceof Integer && t instanceof Integer){
                            sum += Math.pow((((Integer) o).doubleValue() - ((Integer) t).doubleValue()), 2);
                        }else if(o instanceof String){
                            if (o.equals(t)) sum += 1;
                            else sum += 0;
                        }
                    }

                    return Math.sqrt(sum);
                case "manhattan":

                    for(int i = 0; i < featureVector.size(); i++){
                        Object o = f.featureVector.get(i);
                        Object t = this.featureVector.get(i);
                        if(o instanceof Integer && t instanceof Integer) {
                            sum += Math.abs((((Integer) o).doubleValue() - ((Integer) t).doubleValue()));
                        }else if(o  instanceof String && t instanceof String){
                            if(o.equals(t)) sum += 1;
                            else sum += 0;
                        }
                    }
                    return sum;
                case "minkowski":
                    for(int i = 0; i < featureVector.size(); i ++){
                        Object o = f.featureVector.get(i);
                        Object t = this.featureVector.get(i);
                        if(o instanceof Integer && t instanceof Integer) {
                            sum += Math.pow(Math.abs((((Integer) o).doubleValue() - ((Integer) t).doubleValue())), q);
                        }else if(o  instanceof String && t instanceof String){
                            if(o.equals(t)) sum += 1;
                            else sum += 0;
                        }
                    }

                    return Math.pow(sum, (1/q));
                    default:
                        return dist(f, "euclidean", 0);
            }

        }

    }

}
