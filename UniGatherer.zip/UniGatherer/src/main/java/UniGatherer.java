import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import javax.net.ssl.HttpsURLConnection;
import java.awt.geom.Point2D;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;


public class UniGatherer {


    public static void main(String[] args){
        System.out.println("Running UniGatherer");
        UniGatherer ug = new UniGatherer();
        System.out.println(ug.searchByRegion("NorthAmerica"));

    }


    static class Uni implements Clusterable{


        Point2D.Float latLng;

        String name;
        String clusterLabel;

        public Uni(Point2D.Float pos, String name){
            this.latLng = pos;
            this.name = name;
        }

        public Uni(){
            this(new Point2D.Float(Float.MAX_VALUE, Float.MAX_VALUE), "DUMMY");
        }

        @Override
        public String toString(){
            return /*"Name: " + this.name ;*/ " lat: " + latLng.x + " lng: " + latLng.y;
        }

        @Override
        public void setCluster(Object arg) {
            this.clusterLabel = arg.toString();
        }

        @Override
        public Object getClusterLabel() {
            return this.clusterLabel;
        }

    }

    static final Uni dummy = new Uni();

    public UniGatherer(){

    }

    private String concatResponse(InputStream is){
        StringBuilder sb = new StringBuilder();
        try{
            BufferedReader bf = new BufferedReader(new InputStreamReader(is));
            String line;

            while((line = bf.readLine()) != null){
                sb.append(line);
            }
        }catch (IOException io){
            io.printStackTrace();
        }
        return sb.toString();
    }





    List<Uni> searchByRegion(String region){
        StringBuilder sb = new StringBuilder();
        String r1 = null;
        String r2 = null;

        try{
            URL cUrl = new URL("https://maps.googleapis.com/maps/api/place/textsearch/json?query=colleges+in+"+region+"&locationbias=circle:3000000@26.686,30.506&type=college&key=AIzaSyCEEDi3d9JvpAqkAqXIDOFGcw5wwghza3E");
            URL uUrl = new URL("https://maps.googleapis.com/maps/api/place/textsearch/json?query=universities+in+"+region+"&locationbias=circle:3000000@26.686,30.506&type=university&key=AIzaSyCEEDi3d9JvpAqkAqXIDOFGcw5wwghza3E");
            HttpURLConnection conn = (HttpsURLConnection) cUrl.openConnection();

            conn.setRequestMethod("GET");
            conn.setUseCaches(false);
            conn.setDoOutput(true);

            r1 = concatResponse(conn.getInputStream());

            conn = (HttpURLConnection) uUrl.openConnection();
            r2 = concatResponse(conn.getInputStream());

            conn.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }
        List<Uni> ll = parseApiResponse(r1);
        ll.addAll(parseApiResponse(r2));

        return ((r1 != null && r2 != null) ?  ll : new LinkedList<Uni>());
    }

    private List<Uni> parseApiResponse(String response){
        JSONObject jso = null;
        try {
            jso = (JSONObject) new JSONParser().parse(response);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        LinkedList<Uni> unis = new LinkedList<Uni>();

        JSONArray ja = ((JSONArray) jso.get("results"));

        Iterator it = ja.iterator();

        while(it.hasNext()){
            JSONObject currentJsonObj = ((JSONObject) it.next());
            JSONObject geo = (JSONObject) currentJsonObj.get("geometry");
            JSONObject local = (JSONObject) geo.get("location");
            Float lat = Float.parseFloat(local.get("lat").toString());
            Float lng = Float.parseFloat(local.get("lng").toString());
            Point2D.Float pos = new Point2D.Float(lat, lng);
            unis.add(new Uni(pos, (String) currentJsonObj.get("name")));
            //System.out.println(currentJsonObj.get("name"));
        }
        return unis;
    }

    private Point2D.Float parseLatLng(JSONObject jso){

        JSONObject ijso = (JSONObject) jso.get("location");

        float lat = Float.parseFloat((String) ijso.get("lat"));
        float lng = Float.parseFloat((String) ijso.get("lng"));

        return new Point2D.Float(lat,lng);
    }

}
